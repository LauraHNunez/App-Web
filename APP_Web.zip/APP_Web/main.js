function imgWindow() {
 window.open("window")
}
